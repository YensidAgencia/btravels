<?php
$_['label_categories'] = 'Categories';
$_['label_products'] = 'Products';
$_['label_view_all'] = 'View all';
$_['text_no_results'] = 'No results';