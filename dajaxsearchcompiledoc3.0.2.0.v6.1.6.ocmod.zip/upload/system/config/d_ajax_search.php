<?php
$_['d_ajax_search_setting'] = array(
            'class' => '#search [name=search], #search [name=filter_name], #search [name=search_oc]',
            'width' => '372px',
            'max_symbols' => 0,
            'max_results' => 7,
            'price' => 1,
            'image_height' => 60,
            'image_width' => 60,
            'where_search' => 1,
            'block_result' => 1,
            'smart'=>0,
            'suggestion' => 0,
            'all_result_count' => 5,
            'all_result_status' => 1,
            'no_dublicate_images' => 0
        );