<?php

$_['results_for'] = 'Showing results for';
$_['search_phase'] ='Enter search phase above...';
$_['no_results'] ='no results';
//what find
$_['product'] = 'product';
$_['category'] = 'category';
$_['manufacturer'] = 'manufacturer';
$_['information'] = 'information';
$_['blog'] = 'blog';
//find by
$_['name'] = 'name';
$_['description'] = 'description';
$_['model'] = 'model';
$_['manufacturer'] = 'manufacturer';
$_['category'] = 'category';
$_['attribute'] = 'attribute';
$_['title'] = 'title';
$_['meta_title'] = 'meta title';
$_['meta_description'] = 'meta description';
$_['meta_keyword'] = 'meta keyword';
$_['more_results'] = 'More results';
$_['ean'] = 'ean';
$_['upc'] = 'upc';
$_['isbn'] = 'isbn';
$_['mpn'] = 'mpn';
$_['sku'] = 'sku';
$_['jan'] = 'jan';
$_['tag'] = 'tag';

