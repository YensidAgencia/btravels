<?php
/*
 *
 */
class ControllerExtensionDAjaxSearchProduct extends Controller
{

}