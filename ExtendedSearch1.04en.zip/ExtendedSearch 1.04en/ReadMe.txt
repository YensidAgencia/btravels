It's no secret that the standard Opencart search is far from ideal.

- search in fields Model, SKU, EAN, JAN, ISBN and MPN is possible only with strict conformity;
- on the part of the word search is possible only by product name and tags;
- search at attributes is not available;

ExtendedSearch module extends the standard search functionality in the store, allowing you to customize the search engine in the admin panel (in the settings of the module).

When module activated, on the search page will display products with a partial match query in fields Model, SKU, EAN, JAN, ISBN, MPN, Location and attributes.


Features:
---------
- Search by multiple words (or a parts of words) in the fields Model, SKU, EAN, JAN, ISBN and MPN
- Added search at Location field
- Added search at Attributes of goods
- If you disable the corresponding field in the module settings - search on this field will be as before, with standard mechanism of Opencart
- Support Opencart versions 154x-302x

- for versions below 2.0 requires VQMOD
- uses OCMOD for 2.x version


Install 15x:
------------
1. Copy contents from UPLOAD folder into Opencart directory (core files not are replaced)
2. Add permission for module/extendedsearch in System > Users > User Groups
3. Install & configure ExtendedSearch module in Extensions > Modules


Install 2x:
-----------
1. Upload archive ocmod.zip for your version in Extensions > Extension Installer *
2. Refresh modification cache in Extensions > Modifications
3. Add permission for module/extendedsearch in System > Users > User Groups
4. Install & configure ExtendedSearch module in Extensions > Modules

Don`t forget refresh modification cache after install!

* If you don't set up FTP to support archives ocmod.zip in Extension Installer - just use this patch:
http://www.opencart.com/index.php?route=extension/extension/info&extension_id=18892


Install 3x:
-----------
1. Upload archive extended-search_3x.ocmod.zip in Extensions > Installer
2. Refresh the Modifications cache in Extensions > Modifications
3. Refresh theme cache in Dashboard > Developer Settings
4. Add permission for extension/module/extendedsearch in System > Users > User Groups
5. Install & configure ExtendedSearch module in Extensions > Modules


=======================
Thanks for your choise!

If you liked this module - please rate it on module page

More extensions:
https://www.opencart.com/index.php?route=marketplace/extension&filter_member=AlexDW