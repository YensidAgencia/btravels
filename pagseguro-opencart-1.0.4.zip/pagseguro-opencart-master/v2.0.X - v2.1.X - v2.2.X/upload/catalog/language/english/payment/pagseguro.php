<?php
$_["text_title"] 				= "<img src=\"https://www.marjoel.com/github/pagseguro/image/pagseguro.png\" alt=\"PagSeguro\" title=\"PagSeguro\" height=\"20px\">";
$_["text_loading"] 				= "Carregando...";
$_["text_button"] 				= "Pagar com PagSeguro";

$_["error_currency"]			= "PagSeguro :: O PagSeguro só aceita moeda BRL (Real) e a loja está configurada para a moeda %s.";
$_["error_token"]				= "PagSeguro :: Callback - Pedido %s - O token %s é inválido.";
$_["error_parameters"]			= "PagSeguro :: Callback - Os parâmetros são inválidos.";
$_["error_order"]				= "PagSeguro :: Callback - O pedido %s é inválido.";
?>
