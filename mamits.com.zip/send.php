<?php
$field_name = $_POST['cf_name'];
$field_email = $_POST['cf_email'];
$field_phone = $_POST['cf_phone'];
$field_regard = $_POST['cf_regard'];
$field_message = $_POST['cf_message'];


$mail_to = 'mamitsinfo@gmail.com';
$subject = 'Message from a Website Enquiry'.$field_User;


$body_message .= 'User Name: '    .$field_name."\n";
$body_message .= 'User E-mail: '  .$field_email."\n";
$body_message .= 'User Phone: '   .$field_phone."\n";
$body_message .= 'User Subject: ' .$field_regard."\n";
$body_message .= 'User Message: ' .$field_message;



$headers = 'From: '.$field_email."\r\n";
$headers .= 'Reply-To: '.$field_email."\r\n";

$mail_status = mail($mail_to, $subject, $body_message, $headers);

if ($mail_status) { ?>
    <script language="javascript" type="text/javascript">
        alert('Thank you for your Enquiry. We will respond as soon as Possible');
        window.location = 'http://www.mamits.com/oc';
    </script>
<?php
}
else { ?>
    <script language="javascript" type="text/javascript">
        alert('Message failed. Please, send an email to info@mamits.com');
        window.location = 'Tel:+918602741312';
    </script>
<?php
}
?>


           