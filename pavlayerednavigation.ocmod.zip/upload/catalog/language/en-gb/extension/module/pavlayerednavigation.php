<?php 
/******************************************************
 * @package Pavo Layered Navigation Module for Opencart 3.x
 * @version 1.0
 * @author http://www.pavothemes.com
 * @copyright	Copyright (C) Feb 2017 PavoThemes.com <@emai:pavothemes@gmail.com>.All rights reserved.
 * @license		GNU General Public License version 2
*******************************************************/
	$_['heading_title'] = 'Layered Navigation';
	$_['filter_group_categories_name'] = 'Categories';
	$_['filter_group_price_name']  = 'Price range';
	$_['filter_group_selection']   = 'Refine by:';
	$_['filter_group_manufacturers']  = 'Manufacturers'; 
	$_['text_clear_all']		= "Clear All";
?>