<?php
// Heading 
$_['heading_title']  = 'Filter: color'; // Shop by Color | Barva zboží
?>