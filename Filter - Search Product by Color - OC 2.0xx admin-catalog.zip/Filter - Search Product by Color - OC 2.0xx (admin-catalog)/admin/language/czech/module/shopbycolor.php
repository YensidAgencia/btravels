<?php
// Heading
$_['heading_title']    = 'Filtr: Zboží dle barvy (ShopByColor)';

// Text
$_['text_module']      = 'Moduly';
$_['text_success']     = 'Success: You have modified ShopByColor module!';
$_['text_edit']        = 'Úprava modulu ShopByColor';

// Entry
$_['entry_status']     = 'Stav';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module ShopByColor!';