<?php
//Heading
$_['heading_title'] = 'PagSeguro - Débito';

//Text
$_['text_pagseguro_debito'] = '<img src="view/image/payment/pagseguro.png" />';