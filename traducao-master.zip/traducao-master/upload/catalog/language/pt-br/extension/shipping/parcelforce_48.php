<?php
// Text
$_['text_title']       = 'Parcelforce 48';
$_['text_description'] = 'Parcelforce 48';
$_['text_weight']      = 'Weight:';
$_['text_insurance']   = 'Insured upto:';
$_['text_time']        = 'Estimated Time: Within 48 Hours';