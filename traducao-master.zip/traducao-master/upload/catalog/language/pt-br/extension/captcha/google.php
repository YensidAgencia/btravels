<?php
// Text
$_['text_captcha']  = 'Imagem antispam';

// Entry
$_['entry_captcha'] = 'Digite o código no campo abaixo';

// Error
$_['error_captcha'] = 'O código no campo não é o mesmo da imagem!';