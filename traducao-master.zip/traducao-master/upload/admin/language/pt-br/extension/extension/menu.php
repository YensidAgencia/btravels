<?php
// Heading
$_['heading_title']    = 'Menu';

// Text
$_['text_success']     = 'Menu modificado com sucesso!';
$_['text_list']        = 'Listando menu';

// Column
$_['column_name']      = 'Menu';
$_['column_status']    = 'Situação';
$_['column_action']    = 'Ação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar as extensões do tipo menu!';