<?php
// Text
$_['text_subject']  = '%s - Crédito de afiliado';
$_['text_received'] = 'Você recebeu %s de crédito através de nosso programa de afiliados!';
$_['text_total']    = 'O total de seu crédito é: %s.';
$_['text_credit']   = 'Você pode utilizar o seu crédito em sua próxima compra.';