## Como contribuir

 1. Faça um [Fork][fork] do projeto, edite os arquivos e realize os commits.
 2. Envie seu [Pull request][pull-request] para que suas modificações sejam analisadas.
 3. Abra uma [Issue][issues] para notificar sobre bugs.

[pull-request]: https://help.github.com/articles/creating-a-pull-request/
[fork]: https://help.github.com/articles/fork-a-repo/
[issues]: https://github.com/opencartbrasil/traducao/issues
