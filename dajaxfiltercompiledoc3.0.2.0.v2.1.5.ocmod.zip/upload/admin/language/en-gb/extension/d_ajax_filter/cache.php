<?php

$_['heading_title_main']         = 'Ajax Filter';
$_['text_form']                  = 'Create cache';
$_['text_module']                = 'Modules';

$_['button_cancel']              = 'Cancel';

$_['text_installation_progress'] = 'Installation in progress, please wait...';