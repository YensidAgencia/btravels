<?php

//heading
$_['heading_title']           = '<span style="color:#449DD0; font-weight:bold">Ajax Filter</span><span style="font-size:12px; color:#999"> by <a href="http://www.opencart.com/index.php?route=extension/extension&filter_username=Dreamvention" style="font-size:1em; color:#999" target="_blank">Dreamvention</a></span>';
$_['heading_title_main']      = 'Ajax Filter';
$_['text_file_manager']       = 'File Manager';

$_['text_complete_version']   = '<a href="https://shopunity.net/extension/ajax-filter-seo" target="_blank">For filtering with Attributes, Options, Tags, Price and more, please install the full version Ajax Filter SEO</a>';
$_['help_cache_support']      = '<h4>Recreate cache</h4><p>It seems you have made a serious update to the Filter. You will need to re-create your cache for the filter to work correctly.</p>';
$_['text_install_cache']      = 'Re-create';

$_['success_twig_compatible'] = 'Success: Twig support enabled. Please go to Ajax Filter!';