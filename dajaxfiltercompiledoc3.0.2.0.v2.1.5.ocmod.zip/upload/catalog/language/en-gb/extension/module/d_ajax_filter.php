<?php
$_['heading_title']           = 'Ajax Filter';
$_['text_price']              = 'Price range:';
$_['text_manufacturer']       = 'Brand:';
$_['text_stock_status']       = 'Product availability:';
$_['text_rating']             = 'Rating:';
$_['text_search']             = 'Search:';
$_['text_search_placeholder'] = 'Search';
$_['text_category']           = 'Category:';
$_['text_ean']                = 'Ean:';
$_['button_filter']           = 'Filter';
$_['text_tag']                = 'Tags:';
$_['button_reset']            = 'Clear all';
$_['text_shrink']             = 'Shrink';
$_['text_show_more']          = 'View More';
$_['text_not_found']          = '<p>Products Not Found</p>';
$_['text_star']               = '%s star';
